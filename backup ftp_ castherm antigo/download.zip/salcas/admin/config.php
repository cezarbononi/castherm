<?php
// HTTP
define('HTTP_SERVER', 'http://castherm.com.br/salcas/admin/');
define('HTTP_CATALOG', 'http://castherm.com.br/salcas/');

// HTTPS
define('HTTPS_SERVER', 'http://castherm.com.br/salcas/admin/');
define('HTTPS_CATALOG', 'http://castherm.com.br/salcas/');

// DIR
define('DIR_APPLICATION', '/home/storage/2/59/8e/castherm2/public_html/salcas/admin/');
define('DIR_SYSTEM', '/home/storage/2/59/8e/castherm2/public_html/salcas/system/');
define('DIR_DATABASE', '/home/storage/2/59/8e/castherm2/public_html/salcas/system/database/');
define('DIR_LANGUAGE', '/home/storage/2/59/8e/castherm2/public_html/salcas/admin/language/');
define('DIR_TEMPLATE', '/home/storage/2/59/8e/castherm2/public_html/salcas/admin/view/template/');
define('DIR_CONFIG', '/home/storage/2/59/8e/castherm2/public_html/salcas/system/config/');
define('DIR_IMAGE', '/home/storage/2/59/8e/castherm2/public_html/salcas/image/');
define('DIR_CACHE', '/home/storage/2/59/8e/castherm2/public_html/salcas/system/cache/');
define('DIR_DOWNLOAD', '/home/storage/2/59/8e/castherm2/public_html/salcas/download/');
define('DIR_LOGS', '/home/storage/2/59/8e/castherm2/public_html/salcas/system/logs/');
define('DIR_CATALOG', '/home/storage/2/59/8e/castherm2/public_html/salcas/catalog/');

// DB
define('DB_DRIVER', 'mysql');
define('DB_HOSTNAME', 'mysql01.castherm2.hospedagemdesites.ws');
define('DB_USERNAME', 'castherm2');
define('DB_PASSWORD', 'SalPr3ss0stat');
define('DB_DATABASE', 'castherm2');
define('DB_PREFIX', '');
?>