<?php
$subjectPrefix = 'Contato através do site Castherm';
$emailTo = 'contato@castherm.com.br';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name    = stripslashes(trim($_POST['form-name']));
    $email   = stripslashes(trim($_POST['form-email']));
    $subject = stripslashes(trim($_POST['form-subject']));
    $message = stripslashes(trim($_POST['form-message']));
    $pattern  = '/[\r\n]|Content-Type:|Bcc:|Cc:/i';

    if (preg_match($pattern, $name) || preg_match($pattern, $email) || preg_match($pattern, $assunto)) {
        die("Header injection detected");
    }

    $emailIsValid = preg_match('/^[^0-9][A-z0-9._%+-]+([.][A-z0-9_]+)*[@][A-z0-9_]+([.][A-z0-9_]+)*[.][A-z]{2,4}$/', $email);

    if($name && $email && $emailIsValid && $subject && $message){
        $subject = "$subjectPrefix $subject";
        $body = "Nome: $name <br /> Email: $email <br /> Mensagem: $message";

        $headers  = 'MIME-Version: 1.1' . PHP_EOL;
        $headers .= 'Content-type: text/html; charset=utf-8' . PHP_EOL;
        $headers .= "From: $name <$email>" . PHP_EOL;
        $headers .= "Return-Path: $emailTo" . PHP_EOL;
        $headers .= "Reply-To: $email" . PHP_EOL;
        $headers .= "X-Mailer: PHP/". phpversion() . PHP_EOL;

        mail($emailTo, $subject, $body, $headers);
        $emailSent = true;
    } else {
        $hasError = true;
    }
}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Contato Castherm Instrumentos de Medição</title>
<meta name="description" content="Contato Castherm Instrumentos de Medição. Aqui você encontra o instrumento de medição que precisa" />
<meta name="keywords" content="contato, contato castherm, contato@castherm.com.brm, sp, temperatura, castherm, instrumento para temperatura, pirometro infravermelho, termometro, controlador de temperatura" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700' rel='stylesheet' type='text/css'>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-60307049-1', 'auto');
  ga('send', 'pageview');

</script>
<script src="js/jquery.min.js"></script> <!-- start top_js_button -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
   <script type="text/javascript">
		jQuery(document).ready(function($) {
			$(".scroll").click(function(event){		
				event.preventDefault();
				$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
			});
		});
	</script>
</head>
<body>
<!-- start header -->
<div class="header_bg">
<div class="wrap">
	<div class="header">
		<div class="logo">
			<a href="index.php"><img src="images/castherm-comercio-e-servico-de-instrumentacao.jpg" alt="" width="150" height="87"/> </a>
  </div>
		<div class="h_icon">
		<ul class="icon1 sub-icon1">
			<li><a class="active-icon c1" href="#"><i>(11) 4614-4073</i>
            <br><i>(11) 4614-4263</i></a>
				<ul class="sub-icon1 list">
					<li><h3>Entre em contato conosco</h3><a href=""></a></li>
					<li><p><a href="contact.php">contato@castherm.com.br</a></p></li>
				</ul>
			</li>
		</ul>
		</div>
<div class="h_search">
contato@castherm.com.br
</div> 

		<div class="clear"></div>
	</div>
</div>
</div>
<div class="header_btm">
<div class="wrap">
	<div class="header_sub">
<div class="h_menu">
<ul>
<li class="active"><a href="index.php">Home</a></li> |
<li><a href="temperatura.php">Temperatura</a></li> |
<li><a href="umidade.php">Umidade</a></li> |
<li><a href="pressao.php">Pressão</a></li> |
<li><a href="vazao-e-fluxo.php">Vazão e Fluxo</a></li> |
<li><a href="sobre-a-castherm-instrumentos.php">Sobre a Castherm</a></li> |
<li><a href="localizacao.php">Localização</a></li> |
<li><a href="contato.php">Contato</a></li>

</ul>
</div>
<div class="top-nav">
<nav class="nav">	        	
<a href="#" id="w3-menu-trigger"> </a>
<ul class="nav-list" style="">
<li class="nav-item"><li><a href="index.php">Home</a></li> 
<li class="nav-item"><li><a href="temperatura.php">Temperatura</a></li>
<li class="nav-item"><li><a href="umidade.php">Umidade</a></li>
<li class="nav-item"><li><a href="pressao.php">Pressão</a></li>
<li class="nav-item"><li><a href="vazao-e-fluxo.php">Vazão e Fluxo</a></li>
<li class="nav-item"><li><a href="sobre-a-castherm-instrumentos.php">Sobre a Castherm</a></li>
<li class="nav-item"><li><a href="localizacao.php">Localização</a></li>
<li class="nav-item"><li><a href="contato.php">Contato</a></li>
</ul>
</nav>
<div class="search_box">
</div>
<div class="clear"> </div>
<script src="js/responsive.menu.js"></script>

      </div>		  
	<div class="clear"></div>
</div>
</div>
</div>
<!-- start main -->
<div class="main_bg">
<div class="wrap">	
<div class="main">
	 	 <div class="contact">				
					<div class="contact_info">
						<h2>Localização</h2>
			    	 		<div class="map">
					   			<div class="map">
<iframe width="100%" height="250" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d914.0105188488216!2d-46.89434088895609!3d-23.602823920763885!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94cfaa06389b6955%3A0x324dbce176e56ff9!2sR.+Bel%C3%A9m%2C+17+-+Jardim+dos+Ip%C3%AAs%2C+Cotia+-+SP%2C+06716-170!5e0!3m2!1spt-BR!2sbr!4v1425042719715"></iframe><br>
<small><a href="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d914.0105188488216!2d-46.89434088895609!3d-23.602823920763885!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94cfaa06389b6955%3A0x324dbce176e56ff9!2sR.+Bel%C3%A9m%2C+17+-+Jardim+dos+Ip%C3%AAs%2C+Cotia+-+SP%2C+06716-170!5e0!3m2!1spt-BR!2sbr!4v1425042719715" style="color:#777777;text-align:left;font-size:13px;font-family: 'Source Sans Pro', sans-serif;"></a></small>
					   		</div>
      				</div>
				  <div class="contact-form">
                  <h2>Contato</h2>
<?php if(isset($emailSent) && $emailSent): ?>
<div class="col-md-6 col-md-offset-3">
<div class="alert alert-success text-center">Sua mensagem foi enviada com sucesso.</div>
</div>
<?php else: ?>
<?php if(isset($hasError) && $hasError): ?>
<div class="col-md-5 col-md-offset-4">
<div class="alert alert-danger text-center">Houve um erro no envio, tente novamente mais tarde.</div>
</div>
<?php endif; ?>

<div class="col-md-6 col-md-offset-3">
<form action="<?php echo $_SERVER['REQUEST_URI']; ?>" id="contact-form" class="form-horizontal" role="form" method="post">
<div class="form-group">
<label for="name" class="col-lg-2 control-label">Nome</label>
<div class="col-lg-10">
<input type="text" class="form-control required" id="form-name" name="form-name" placeholder="Nome" />
</div>
</div>
<div class="form-group">
<label for="email" class="col-lg-2 control-label">Email</label>
<div class="col-lg-10">
<input type="email" class="form-control required" id="form-email" name="form-email" placeholder="Email" />
</div>
</div>
<div class="form-group">
<label for="assunto" class="col-lg-2 control-label">Assunto</label>
<div class="col-lg-10">
<input type="text" class="form-control required" id="form-subject" name="form-subject" placeholder="Assunto" />
</div>
</div>
<div class="form-group">
<label for="mensagem" class="col-lg-2 control-label">Mensagem</label>
<div class="col-lg-10">
<textarea class="form-control required" rows="3" id="form-message" name="form-message" placeholder="Mensagem" /></textarea>
</div>
</div>
<div class="form-group">
<div class="col-lg-offset-2 col-lg-10">
<span><button type="submit" class="btn btn-default">Enviar</button></span>

</div>
</div>
</form>
</div>
<?php endif; ?>
    
  
		 	  	
  				<div class="clear"></div>		
			  </div>
		</div>
</div>
</div>		
<!-- start footer -->
<div class="footer_bg">
  <div class="wrap">
    <div class="footer">
      <!-- start grids_of_4 -->
      <div class="grids_of_4">
        <div class="grid1_of_4">
          <h4>Informações Úteis</h4>
          <ul class="f_nav">
            <li><a href="sobre-a-castherm.php">Sobre a Castherm</a></li>
            <li></li>
            <li></li>
          </ul>
        </div>
        <div class="grid1_of_4">
          <h4>Instrumentos</h4>
          <ul class="f_nav">
            <li><a href="temperatura.php">Temperatura</a></li>
            <li><a href="umidade.php">Umidade</a></li>
            <li><a href="pressao.php">Pressão</a></li>
            <li><a href="vazao-e-fluxo.php">Vazão e Fluxo</a></li>
          </ul>
        </div>
        <div class="grid1_of_4">
          <h4>Endereço</h4>
          <ul class="f_nav">
            <li>A Castherm está localizada:</li>
            <li>Rua Belém, 17 | Jardim dos Ipês</li>
            <li>Cotia | São Paulo</li>
            <li>Cep: 06716-170</li>
          </ul>
        </div>
        <div class="grid1_of_4">
          <h4>Contatos castherm</h4>
          <ul class="f_nav">
            <li>Telefone: (11) 4614-4073</li>
            <li>Telefone: (11)  4614-4263</li>
            <li>Telefone: (11) 4614-4295</li>
            <li>E-mail: <a href="mailto:contato@castherm.com.br">contato@castherm.com.br</a></li>
          </ul>
        </div>
        <div class="clear"></div>
      </div>
    </div>
  </div>
</div>
<!-- start footer -->
<div class="footer_bg1">
  <div class="wrap">
    <div class="footer">
      <!-- scroll_top_btn -->
      <script type="text/javascript">
			$(document).ready(function() {
			
				var defaults = {
		  			containerID: 'toTop', // fading element id
					containerHoverID: 'toTopHover', // fading element hover id
					scrollSpeed: 1200,
					easingType: 'linear' 
		 		};
				
				
				$().UItoTop({ easingType: 'easeOutQuart' });
				
			});
		</script>
      <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
      <!--end scroll_top_btn -->
      <div class="copy">
        <p class="link">&copy;  Todos os direitos Reservados Castherm  Comércio e Serviços de Instrumentos de  Medição e Automatização Ltda </p>
      </div>
      <div class="clear"></div>
    </div>
  </div>
</div>
</body>
</html>