<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Umidade - Todos os instrumentos de umidade na Castherm</title>
<meta name="description" content="Instrumentos de umidade: Datalogger, datalogger de umidade, Termohigrometro, psicrometro, você encontra na Castherm" />
<meta name="keywords" content="umidade, castherm, instrumento para umidade, termohigrometro, psicrometro, datalogger de umidade" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700' rel='stylesheet' type='text/css'>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-60307049-1', 'auto');
  ga('send', 'pageview');

</script>
<script src="js/jquery.min.js"></script> <!-- start top_js_button -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
   <script type="text/javascript">
    jQuery(document).ready(function($) {
      $(".scroll").click(function(event){    
        event.preventDefault();
        $('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
      });
    });
  </script>
</head>
<body>
<!-- start header -->
<div class="header_bg">
<div class="wrap">
  <div class="header">
    <div class="logo">
      <a href="index.php"><img src="images/castherm-comercio-e-servico-de-instrumentacao.jpg" alt="" width="150" height="87"/> </a>
</div>
    <div class="h_icon">
    <ul class="icon1 sub-icon1">
      <li><a class="active-icon c1" href="#"><i>(11) 4614-4073</i>
            <br><i>(11) 4614-4263</i></a>
        <ul class="sub-icon1 list">
          <li><h3>Entre em contato conosco</h3><a href=""></a></li>
          <li><p><a href="contact.php">contato@castherm.com.br</a></p></li>
        </ul>
      </li>
    </ul>
    </div>
<div class="h_search">
contato@castherm.com.br
</div> 

    <div class="clear"></div>
  </div>
</div>
</div>
<div class="header_btm">
<div class="wrap">
  <div class="header_sub">
<div class="h_menu">
<ul>
<li class="active"><a href="index.php">Home</a></li> |
<li><a href="temperatura.php">Temperatura</a></li> |
<li><a href="umidade.php">Umidade</a></li> |
<li><a href="pressao.php">Pressão</a></li> |
<li><a href="vazao-e-fluxo.php">Vazão e Fluxo</a></li> |
<li><a href="sobre-a-castherm-instrumentos.php">Sobre a Castherm</a></li> |
<li><a href="localizacao.php">Localização</a></li> |
<li><a href="contato.php">Contato</a></li>

</ul>
</div>
<div class="top-nav">
<nav class="nav">            
<a href="#" id="w3-menu-trigger"> </a>
<ul class="nav-list" style="">
<li class="nav-item"><li><a href="index.php">Home</a></li> 
<li class="nav-item"><li><a href="temperatura.php">Temperatura</a></li>
<li class="nav-item"><li><a href="umidade.php">Umidade</a></li>
<li class="nav-item"><li><a href="pressao.php">Pressão</a></li>
<li class="nav-item"><li><a href="vazao-e-fluxo.php">Vazão e Fluxo</a></li>
<li class="nav-item"><li><a href="sobre-a-castherm-instrumentos.php">Sobre a Castherm</a></li>
<li class="nav-item"><li><a href="localizacao.php">Localização</a></li>
<li class="nav-item"><li><a href="contato.php">Contato</a></li>
</ul>
</nav>
<div class="search_box">
</div>
<div class="clear"> </div>
<script src="js/responsive.menu.js"></script>

         </div>      
  <div class="clear"></div>
</div>
</div>
</div>
<!-- start main -->
<div class="main_bg">
<div class="wrap">  
  <div class="main">
    <h2 class="style top">Umidade</h2>
    <p>Veja alguns modelos de instrumentos de medição de Umidade abaixo:</p>
    <!-- start grids_of_3 -->
    <div class="grids_of_3">
      <div class="grid1_of_3">
        <a href="termohigrometro-digital-sa-7429.php">
          <img src="images/produtos/termohigrometro-digital-sa-7429.jpg" alt="Termometro Testo 735-2" width="169" height="200"/>
<h3>Termohigrômetro SA 7429</h3>
          <div class="price">
            <h4><span>Saiba mais</span></h4>
          </div>
          <span class="b_btm"></span>
        </a>
      </div>
      <div class="grid1_of_3">
        <a href="termohigrometro-analogico-sa-5048-00.php">
          <img src="images/produtos/termohigrometro-analogico-sa-5048-00.jpg" alt="Termohigrômetro Analógico SA 5048.00" width="169" height="200"/>
<h3>Termohigrômetro 5048.00</h3>
          <div class="price">
            <h4><span>Saiba mais</span></h4>
          </div>
          <span class="b_btm"></span>
        </a>
    </div>

      <div class="clear"></div>
    </div>  
    <!-- end grids_of_3 -->
  </div>
</div>
</div>  
<!-- start footer -->
<div class="footer_bg">
  <div class="wrap">
    <div class="footer">
      <!-- start grids_of_4 -->
      <div class="grids_of_4">
        <div class="grid1_of_4">
          <h4>Informações Úteis</h4>
          <ul class="f_nav">
            <li><a href="sobre-a-castherm.php">Sobre a Castherm</a></li>
            <li></li>
            <li></li>
          </ul>
        </div>
        <div class="grid1_of_4">
          <h4>Instrumentos</h4>
          <ul class="f_nav">
            <li><a href="temperatura.php">Temperatura</a></li>
            <li><a href="umidade.php">Umidade</a></li>
            <li><a href="pressao.php">Pressão</a></li>
            <li><a href="vazao-e-fluxo.php">Vazão e Fluxo</a></li>
          </ul>
        </div>
        <div class="grid1_of_4">
          <h4>Endereço</h4>
          <ul class="f_nav">
            <li>A Castherm está localizada:</li>
            <li>Rua Belém, 17 | Jardim dos Ipês</li>
            <li>Cotia | São Paulo</li>
            <li>Cep: 06716-170</li>
          </ul>
        </div>
        <div class="grid1_of_4">
          <h4>Contatos castherm</h4>
          <ul class="f_nav">
            <li>Telefone: (11) 4614-4073</li>
            <li>Telefone: (11)  4614-4263</li>
            <li>Telefone: (11) 4614-4295</li>
            <li>E-mail: <a href="mailto:contato@castherm.com.br">contato@castherm.com.br</a></li>
          </ul>
        </div>
        <div class="clear"></div>
      </div>
    </div>
  </div>
</div>
<!-- start footer -->
<div class="footer_bg1">
  <div class="wrap">
    <div class="footer">
      <!-- scroll_top_btn -->
      <script type="text/javascript">
      $(document).ready(function() {
      
        var defaults = {
            containerID: 'toTop', // fading element id
          containerHoverID: 'toTopHover', // fading element hover id
          scrollSpeed: 1200,
          easingType: 'linear' 
         };
        
        
        $().UItoTop({ easingType: 'easeOutQuart' });
        
      });
    </script>
      <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
      <!--end scroll_top_btn -->
      <div class="copy">
        <p class="link">&copy;  Todos os direitos Reservados Castherm  Comércio e Serviços de Instrumentos de  Medição e Automatização Ltda </p>
      </div>
      <div class="clear"></div>
    </div>
  </div>
</div>
</body>
</html>