﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="DESCRIPTION" content="Castherm Instrumentação e Controle: Manômetros, Termômetros, e muito mais"/> 
<meta name="KEYWORDS" content="castherm, instrumentacao, controle, termometro, manometro"/> 
<meta name="language" content="portuguese, PT-BR" />
<link href="style.css" rel="stylesheet" type="text/css"/>
<title>Castherm Instrumentação e Controle: Manômetros, Termômetros</title>

<script type="text/javascript">
function checkEmail (strng) {
	var flagError = false;
	var error="";
	
	if (strng == "") {
		error = "O endereço de e-mail deve ser preenchido.";
		flagError = true;
	}
	
	if (!flagError) {
		var illegalChars = /(@.*@)|(@\.)|(@\-)|(@_)(\.@)|(\-@)|(\.\.)|(^\.)|(\.$)|(\.\-)|(\._)|(\-\.)|(_\.)|(^_)|(_$)|(_\-)|(\-\-)|(^\-)|(\-$)|(\-_)/;
		if (strng.match(illegalChars)) {
			error = "O endereço de e-mail contém caracteres inválidos.";
			flagError = true;
		}
	}

	if (!flagError) {
		var emailFilter = /^\S+\@(\[?)[a-zA-Z0-9_\-\.]+\.([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
		if (!(emailFilter.test(strng))) { 
			error = "O endereço de e-mail não está em um formato válido.";
			flagError = true;
		}
	}

	if (!flagError) {
		var emailFilter = /^([a-zA-Z0-9\@_\-\.\+]+)$/;
		if (!(emailFilter.test(strng))) { 
			error = "O endereço de e-mail não está em um formato válido.";
			flagError = true;
		}
	}

	if (flagError) {
		window.alert(error);
	}

	return !flagError;
}
</script>

</head>

<body>
<table width="1024" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><a href="mailto:contato@castherm.com.br"><img src="site-logotipo-castherm-instrumentação-e-controle.jpg" alt="Castherm Instrumentacao e Controle" width="1024" height="187" class="img" /></a></td>
  </tr>
  <tr>
    <td><img src="site-castherm-instrumentação-e-controle-em-construcao.jpg" alt="Castherm Instrumentacao e Controle - Site em Construção" width="1024" height="378" class="img" /></td>
  </tr>
  <tr>
    <td><p>OBRIGADO POR SEU CONTATO.</p>
    <p>EM BREVE ENTRAREMOS EM CONTATO.</p>
    <p>&nbsp;</p>
    <h1>CASTHERM INSTRUMENTAÇÃO E CONTROLE</h1></td>
  </tr>
</table>
</body>
</html>
