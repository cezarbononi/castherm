<?php echo $header; ?>
<div id="content">
<div class="breadcrumb">
  <?php foreach ($breadcrumbs as $breadcrumb) { ?>
  <?php echo $breadcrumb['separator']; ?><a href="<?php echo $breadcrumb['href']; ?>"><?php echo $breadcrumb['text']; ?></a>
  <?php } ?>
</div>
<?php if ($error_warning) { ?>
<div class="warning"><?php echo $error_warning; ?></div>
<?php } ?>
<div class="box">
  <div class="heading">
    <h1><img src="view/image/module.png" alt="" /> <?php echo $heading_title; ?></h1>
    <div class="buttons"><a onclick="$('#form').submit();" class="button"><span><?php echo $button_save; ?></span></a><a onclick="location = '<?php echo $cancel; ?>';" class="button"><span><?php echo $button_cancel; ?></span></a></div>
  </div>
  <div class="content">
    <div id="tabs" class="htabs">
        <a href="#tab-1"><span><?php echo $entry_area1; ?></span></a>
        <a href="#tab-2"><span><?php echo $entry_area2; ?></span></a>
        <a href="#tab-3"><span>PRO Features</span></a>
    </div>
    <form action="<?php echo $action; ?>" method="post" enctype="multipart/form-data" id="form">
    <div id="tab-1" style="clear: both;">
      <table class="form">
        <tr>
          <td><?php echo $entry_enabled; ?></td>
          <td><select name="cr2landpage_status">
                <?php if ($cr2landpage_status) { ?>
                <option value="1" selected="selected"><?php echo $text_enabled; ?></option>
                <option value="0"><?php echo $text_disabled; ?></option>
                <?php } else { ?>
                <option value="1"><?php echo $text_enabled; ?></option>
                <option value="0" selected="selected"><?php echo $text_disabled; ?></option>
                <?php } ?>
              </select></td>
        </tr>
        <tr>
          <td><?php echo $entry_includejs; ?></td>
          <td><select name="cr2landpage_includejs">
                <?php if ($cr2landpage_includejs) { ?>
                <option value="0"><?php echo $text_disabled; ?></option>
                <option value="1" selected="selected"><?php echo $text_enabled; ?></option>
                <?php } else { ?>
                <option value="0" selected="selected"><?php echo $text_disabled; ?></option>
                <option value="1"><?php echo $text_enabled; ?></option>
                <?php } ?>
              </select></td>
        </tr>
        <tr>
          <td><?php echo $entry_moduleposition; ?></td>
          <td><select name="cr2landpage_moduleposition">
                <option value="content_top" <?php echo ($cr2landpage_moduleposition=="content_top"?"selected=\"selected\"":""); ?>><?php echo $entry_contenttop; ?></option>
                <option value="content_bottom" <?php echo ($cr2landpage_moduleposition=="content_bottom"?"selected=\"selected\"":""); ?>><?php echo $entry_contentbottom; ?></option>
                <option value="column_left" <?php echo ($cr2landpage_moduleposition=="column_left"?"selected=\"selected\"":""); ?>><?php echo $entry_columnleft; ?></option>
                <option value="column_right" <?php echo ($cr2landpage_moduleposition=="column_right"?"selected=\"selected\"":""); ?>><?php echo $entry_columnright; ?></option>
          </select><br />
          <span class="help"><?php echo $help_moduleposition; ?></span></td>
        </tr>
        <tr>
          <td><?php echo $entry_width; ?></td>
          <td><input name="cr2landpage_width" value="<?php echo $cr2landpage_width; ?>" size="10">px</td>
        </tr>
        <tr>
          <td><?php echo $entry_height; ?></td>
          <td><input name="cr2landpage_height" value="<?php echo $cr2landpage_height; ?>" size="10">px</td>
        </tr>
        <tr>
           <td><?php echo $entry_layouts; ?></td>
           <td><select name="cr2landpage_layouts[]" multiple size=10>
           <?php foreach($layouts as $layout){ ?>
                <option value="<?php echo $layout['layout_id']; ?>" <?php if (in_array($layout['layout_id'],$cr2landpage_layouts)) { ?> selected="selected" <?php }; ?>><?php echo ucwords($layout['name']); ?></option>
           <?php }?>
           </select><br /><span class="help"><?php echo $help_layouts; ?></span></td>
        </tr>
        <tr>
           <td><?php echo $entry_layoutcount; ?></td>
           <td><b><?php echo $cr2landpage_layoutcount; ?></b>
           <?php if ($cr2landpage_layoutcount<11) {?><br /><span class="help" style="color: red;"><?php echo $entry_layoutwarning; ?></span> <?php }; ?></td>
        </tr>
      </table>
     </div><!--area1-->
     <div id="tab-2" style="clear: both;">
      <table class="form">
        <tr>
          <td><?php echo $entry_mode; ?></td>
          <td><select name="cr2landpage_mode" onchange="switch_mode(this.value);" id="modeselector">
                <option value="0"><?php echo $text_mode1; ?></option>
                <option value="1" selected="selected"><?php echo $text_mode2; ?></option>
                <option value="2"><?php echo $text_mode3; ?></option>
              </select></td>
        </tr>
        <tr>
          <td><div id="modetitle">&nbsp;</div></td>
          <td>
          <div id="mode0" class="amode">
               <table class="">
               <tr><td>
               <h4>Easily add custom HTML content to your landing page. This feature is available in the PRO version of the module.</h4>
               </td></tr>
               </table>
          </div>
          <div id="mode1" class="amode">
                <table class="form">
               	<?php foreach ($languages as $language) { ?>
                    <tr>
                         <td><input name="cr2landpage_remoteurl_<?php echo $language['language_id']; ?>" value="<?php echo isset(${'cr2landpage_remoteurl_' . $language['language_id']}) ? ${'cr2landpage_remoteurl_' . $language['language_id']} : ''; ?>" size="100">
                         	<img src="view/image/flags/<?php echo $language['image']; ?>" title="<?php echo $language['name']; ?>" style="vertical-align: top;" /><br />
                         </td>
               	</tr>
               	<?php } ?>
               	<tr><td><?php echo $help_remoteurl; ?></td></tr>
               </tr>
               </table>
          </div>
          <div id="mode2" class="amode">
               <table class="">
               <tr><td>
               <h4>Easily select a built-in Information Page as content for your landing page. This feature is available in the PRO version of the module.</h4>
               </td></tr>
               </table>
          </div>
          </td>
        </tr>
      </table>
     </div><!--area2-->
    <div id="tab-3" style="clear: both; font-size: 1.1em;">
    <br />
    <b>CR2 Landing Page Pro features:</b><br />
    <ul>
         <li>easily type in your custom HTML which will then be displayed in the landing page (for each store language)</li>
         <li>easily select on of the Information Page to be displayed as the landing page content</li>
         <li>configure the colour and opacity of the overlay (the area covering the outside the landing page content)</li>
    </ul>
    <br />
    <b><a href="http://demos.cryoutcreations.eu/opencart/modules/" target="_blank">View the demo</a>,
    check out the <a href="http://www.cryoutcreations.eu/landing-page/" target="_blank">feature comparison chart</a>,
    or <a href="http://www.opencart.com/index.php?route=extension/extension/info&extension_id=9737" target="_blank">get the PRO version</a>.</b>
    <br /><br /><br /><br />
    </div><!--area3-->
    </form>
  </div>
	<div style="text-align:center; color:#666666;">
		CR2 Landing Page v<?php echo $_version; ?> &bull; <a href="http://www.cryoutcreations.eu/landing-page/" target="_blank">Support</a>
	</div>
</div>
<style type="text/css"> .amode { display: none; } </style>
<script type="text/javascript"><!--
$("#modeselector").trigger("change");
function switch_mode(val){
switch(val){
     case "0": case 0: $(".amode").fadeOut(100,function() { $("#mode0").fadeIn(200) }); $("#modetitle").html('<?php echo $label_mode1; ?>'); break;
     case "1": case 1: $(".amode").fadeOut(100,function() { $("#mode1").fadeIn(200) }); $("#modetitle").html('<?php echo $label_mode2; ?>'); break;
     case "2": case 2: $(".amode").fadeOut(100,function() { $("#mode2").fadeIn(200) });  $("#modetitle").html('<?php echo $label_mode3; ?>'); break;
     default:
} // switch
}

$(function() { $('#tabs a').tabs();  });
//--></script>
<?php echo $footer; ?>