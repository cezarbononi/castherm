<!-- 
 * @package NVisitors
 * @version 0.2.1
 -->

<?php 
$bid = $nvisitors_username; $secKey = $nvisitors_password; 
?>
<div id='notifyvisitorstag'></div>
<script>
var notify_visitors = window.notify_visitors || {}; (function() { 
        notify_visitors.auth = { bid_e : '<?php print $secKey; ?>',
        bid : '<?php print $bid; ?>', t : '420' };	
        var script = document.createElement('script');script.async = true;
        script.src = (document.location.protocol == 'https:' ? '//d2933uxo1uhve4.cloudfront.net' : '//cdn.notifyvisitors.com') + '/js/notify-visitors-1.0.js';
        var entry = document.getElementsByTagName('script')[0];entry.parentNode.insertBefore(script, entry); })();
</script>
