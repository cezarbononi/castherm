
<?php /* cr2 landing page v1.02 */
if ($status) { ?>
     <!-- CR2 Landing Page v<?php echo $version; ?> -->
     <?php if ($includejs) { ?>
          <script type="text/javascript" src="<?php echo $storeurl; ?>catalog/view/javascript/jquery/colorbox/jquery.colorbox.js"></script>
          <link rel="stylesheet" type="text/css" href="<?php echo $storeurl; ?>catalog/view/javascript/jquery/colorbox/colorbox.css" media="screen" />
     <?php }; // if includejs ?>
     <script type="text/javascript"><!--
          $(document).ready(function() {
               $.fn.colorbox({href:"<?php echo $remoteurl; ?>", iframe: true, innerWidth: <?php echo $width; ?>, innerHeight: <?php echo $height; ?>});
          });
     --></script>
<?php }; // if status ?>
