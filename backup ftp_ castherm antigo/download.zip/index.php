<!DOCTYPE HTML>
<html>
<head>
<title>Castherm Instrumentos de Medição</title>
<meta name="description" content="Castherm Instrumentos de medição: Termometro, Pirometro Infravermelho, Termohigrometro, controladores, você encontra na Castherm" />
<meta name="keywords" content="Instrumentos de medição,temperatura, castherm, instrumento para temperatura, pirometro infravermelho, termometro, controlador de temperatura" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700' rel='stylesheet' type='text/css'>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<!-- start slider -->    
  <link href="css/slider.css" rel="stylesheet" type="text/css" media="all" />
  <script type="text/javascript" src="js/modernizr.custom.28468.js"></script>
  <script type="text/javascript" src="js/jquery.cslider.js"></script>
  <script type="text/javascript">
    $(function() {
      $('#da-slider').cslider();
    });
  </script>
    <!-- Owl Carousel Assets -->
    <link href="css/owl.carousel.css" rel="stylesheet">
         <!-- Owl Carousel Assets -->
        <!-- Prettify -->
        <script src="js/owl.carousel.js"></script>
            <script>
        $(document).ready(function() {
    
          $("#owl-demo").owlCarousel({
            items : 4,
            lazyLoad : true,
            autoPlay : true,
            navigation : true,
          navigationText : ["",""],
          rewindNav : false,
          scrollPerPage : false,
          pagination : false,
          paginationNumbers: false,
          });
    
        });
        </script>
       <!-- //Owl Carousel Assets -->
    <!-- start top_js_button -->
    <script type="text/javascript" src="js/move-top.js"></script>
    <script type="text/javascript" src="js/easing.js"></script>
        <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-60307049-1', 'auto');
  ga('send', 'pageview');

</script>

       <script type="text/javascript">
        jQuery(document).ready(function($) {
          $(".scroll").click(function(event){    
            event.preventDefault();
            $('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
          });
        });
      </script>
</head>
<body>
<!-- start header -->
<div class="header_bg">
<div class="wrap">
  <div class="header">
    <div class="logo">
      <a href="index.php"><img src="images/castherm-comercio-e-servico-de-instrumentacao.jpg" alt="" width="150" height="87"/> </a>
  </div>
    <div class="h_icon">
    <ul class="icon1 sub-icon1">
      <li><a class="active-icon c1" href="#"><i>(11) 4614-4073</i>
            <br><i>(11) 4614-4263</i></a>
        <ul class="sub-icon1 list">
          <li><h3>Entre em contato conosco</h3><a href=""></a></li>
          <li><p><a href="contact.php">contato@castherm.com.br</a></p></li>
        </ul>
      </li>
    </ul>
    </div>
<div class="h_search">
contato@castherm.com.br
</div> 

    <div class="clear"></div>
  </div>
</div>
</div>
<div class="header_btm">
<div class="wrap">
  <div class="header_sub">
<div class="h_menu">
<ul>
<li class="active"><a href="index.php">Home</a></li> |
<li><a href="temperatura.php">Temperatura</a></li> |
<li><a href="umidade.php">Umidade</a></li> |
<li><a href="pressao.php">Pressão</a></li> |
<li><a href="vazao-e-fluxo.php">Vazão e Fluxo</a></li> |
<li><a href="sobre-a-castherm-instrumentos.php">Sobre a Castherm</a></li> |
<li><a href="localizacao.php">Localização</a></li> |
<li><a href="contato.php">Contato</a></li>

</ul>
</div>
<div class="top-nav">
<nav class="nav">            
<a href="#" id="w3-menu-trigger"> </a>
<ul class="nav-list" style="">
<li class="nav-item"><li><a href="index.php">Home</a></li> 
<li class="nav-item"><li><a href="temperatura.php">Temperatura</a></li>
<li class="nav-item"><li><a href="umidade.php">Umidade</a></li>
<li class="nav-item"><li><a href="pressao.php">Pressão</a></li>
<li class="nav-item"><li><a href="vazao-e-fluxo.php">Vazão e Fluxo</a></li>
<li class="nav-item"><li><a href="sobre-a-castherm-instrumentos.php">Sobre a Castherm</a></li>
<li class="nav-item"><li><a href="localizacao.php">Localização</a></li>
<li class="nav-item"><li><a href="contato.php">Contato</a></li>
</ul>
</nav>
<div class="search_box">
</div>
<div class="clear"> </div>
<script src="js/responsive.menu.js"></script>
         </div>      
  <div class="clear"></div>
</div>
</div>
</div>
<!-- start slider -->
      <div id="da-slider" class="da-slider">
        <div class="da-slide">
          <h2>Instrumentos para Temperatura</h2>
          <p>A Castherm conta com uma grande linha de Termômetros, Controladores, Data Loggers, Sondas de Temperatura, Termohigrômetros e muito mais.</p>
          <a href="temperatura.php" class="da-link">Acesse</a>
          <div class="da-img"><img src="images/slider11.png" alt="Temperatura"></div>
        </div>
        <div class="da-slide">
          <h2>Instrumentos para Pressão</h2>
          <p>Contamos com uma excelente linha de Manômetros Analógicos e Digitais, Barômetros, Altímetros, Bombas de Calibração, Pressostatos, dentre outros.</p>
          <a href="pressao.php" class="da-link">Acesse</a>
          <div class="da-img"><img src="images/slider2.png" alt="Pressao" /></div>
        </div>
        
        <nav class="da-arrows">
          <span class="da-arrows-prev"></span>
          <span class="da-arrows-next"></span>
        </nav>
      </div>
        </div>
<!----start-cursual---->
<div class="wrap">
<!----start-img-cursual---->
  <div id="owl-demo" class="owl-carousel">
 
        
<div class="item" onclick="location.href='termometro-infravermelho-fluke-572.php';">
<div class="cau_left">
<img class="lazyOwl" width="158" height="119" data-src="images/produtos/termometro-infravermelho-fluke-572.jpg" alt="Termômetro Fluke 572">
</div>
<div class="cau_left">
<h4><a href="termometro-infravermelho-fluke-572.php">Termômetro Fluke 572</a></h4>
<a href="termometro-infravermelho-fluke-572.php" class="btn">Saiba mais</a>
</div>

    </div>  
<div class="item" onclick="location.href='termohigrometro-digital-sa-7429.php';">
<div class="cau_left">
<img class="lazyOwl" width="158" height="119" data-src="images/produtos/termohigrometro-digital-sa-7429.jpg" alt="Termohigrômetro Digital SA 7429">
</div>
<div class="cau_left">
<h4><a href="termohigrometro-digital-sa-7429.php">Termohigrômetro Digital SA 7429</a></h4>
<a href="termohigrometro-digital-sa-7429.php" class="btn">Saiba mais</a>
</div>
 </div>

  <!----//End-img-cursual---->
</div>
<!-- start main1 -->
<div class="main_bg1">
<div class="wrap">  
  <div class="main1">
    <h2>Instrumentos em Destaque</h2>
  </div>
</div>
</div>
<!-- start main -->
<div class="main_bg">
<div class="wrap">  
  <div class="main">
    <!-- start grids_of_3 -->
    <div class="grids_of_3">

      </div>
      <div class="grid1_of_3">
        <a href="termometro-infravermelho-fluke-572.php">
          <img src="images/produtos/termometro-infravermelho-fluke-572.jpg" alt="Termômetro Fluke 572" width="116" height="137"/>
<h3>Termômetro Fluke 572</h3>
          <div class="price">
            <h4><span>Saiba mais</span></h4>
          </div>
          <span class="b_btm"></span>
        </a>
      </div>

      <div class="grid1_of_3">
        <a href="Controlador-de-Temperatura-SCT1040.php">
          <img src="images/produtos/controlador-de-temperatura-sct1040-castherm.jpg" alt="Controlador SCT 1040" width="116" height="137"/>
<h3>Controlador SCT 1040</h3>
          <div class="price">
            <h4><span>Saiba mais</span></h4>
          </div>
          <span class="b_btm"></span>
        </a>
      </div>
      <div class="grid1_of_3">
        <a href="termohigrometro-analogico-sa-5048-00.php">
          <img src="images/produtos/termohigrometro-analogico-sa-5048-00.jpg" alt="Termohigrômetro 5048.00" width="116" height="137"/>
<h3>Termohigrômetro 5048.00</h3>
          <div class="price">
            <h4><span>Saiba mais</span></h4>
          </div>
          <span class="b_btm"></span>
        </a>
      </div>
      <div class="grid1_of_3">
        <a href="termohigrometro-digital-sa-7429.php">
          <img src="images/produtos/termohigrometro-digital-sa-7429.jpg" alt="Termohigrômetro SA 7429" width="116" height="137"/>
<h3>Termohigrômetro SA 7429</h3>
          <div class="price">
            <h4><span>Saiba mais</span></h4>
          </div>
          <span class="b_btm"></span>
        </a>
      </div>
      <div class="clear"></div>
    </div>  
    <!-- end grids_of_3 -->
  </div>
</div>
</div>  
<!-- start footer -->
<div class="footer_bg">
<div class="wrap">  
  <div class="footer">
    <!-- start grids_of_4 -->  
    <div class="grids_of_4">
      <div class="grid1_of_4">
        <h4>Informações Úteis</h4>
        <ul class="f_nav">
          <li><a href="sobre-a-castherm.php">Sobre a Castherm</a></li>
          <li></li>
          <li></li>
        </ul>
      </div>
      <div class="grid1_of_4">
        <h4>Instrumentos</h4>
        <ul class="f_nav">
          <li><a href="temperatura.php">Temperatura</a></li>
          <li><a href="umidade.php">Umidade</a></li>
          <li><a href="pressao.php">Pressão</a></li>
          <li><a href="vazao-e-fluxo.php">Vazão e Fluxo</a></li>
        </ul>
      </div>
      <div class="grid1_of_4">
        <h4>Endereço</h4>
        <ul class="f_nav">
          <li>A Castherm está localizada:</li>
                    <li>Rua Belém, 17 | Jardim dos Ipês</li>
          <li>Cotia | São Paulo</li>
          <li>Cep: 06716-170</li>
          
        </ul>
      </div>
      <div class="grid1_of_4">
        <h4>Contatos castherm</h4>
        <ul class="f_nav">
          <li>Telefone: (11) 4614-4073</li>
          <li>Telefone: (11)  4614-4263</li>
          <li>Telefone: (11) 4614-4295</li>
          <li>E-mail: <a href="mailto:contato@castherm.com.br">contato@castherm.com.br</a></li>
        </ul>
      </div>
      <div class="clear"></div>
    </div>
  </div>
</div>
</div>  
<!-- start footer -->
<div class="footer_bg1">
<div class="wrap">
  <div class="footer">
    <!-- scroll_top_btn -->
      <script type="text/javascript">
      $(document).ready(function() {
      
        var defaults = {
            containerID: 'toTop', // fading element id
          containerHoverID: 'toTopHover', // fading element hover id
          scrollSpeed: 1200,
          easingType: 'linear' 
         };
        
        
        $().UItoTop({ easingType: 'easeOutQuart' });
        
      });
    </script>
     <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
    <!--end scroll_top_btn -->
    <div class="copy">
      <p class="link">&copy;  Todos os direitos Reservados Castherm  Comércio e Serviços de Instrumentos de  Medição e Automatização Ltda </p>
    </div>
    <div class="clear"></div>
  </div>
</div>
</div>
</body>
</html>
