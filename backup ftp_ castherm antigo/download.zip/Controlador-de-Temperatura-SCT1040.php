<!DOCTYPE HTML>
<html>
<head>
<title>Controlador de Temperatura SCT1040 Castherm</title>
<meta name="description" content="O mais fantástico Controlador de Temperatura SCT1040 você encontra na Castherm. Ótimo preço, excelente qualidade" />
<meta name="keywords" content="castherm, controlador de temperatura, Controlador de Temperatura SCT1040, SCT1040" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700' rel='stylesheet' type='text/css'> 
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- start details -->
<link rel="stylesheet" type="text/css" href="css/productviewgallery.css" media="all" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/cloud-zoom.1.0.3.min.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox-buttons.js"></script>
<script type="text/javascript" src="js/jquery.fancybox-thumbs.js"></script>
<script type="text/javascript" src="js/productviewgallery.js"></script>
<!-- start top_js_button -->
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-60307049-1', 'auto');
  ga('send', 'pageview');

</script>

   <script type="text/javascript">
		jQuery(document).ready(function($) {
			$(".scroll").click(function(event){		
				event.preventDefault();
				$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
			});
		});
	</script>
</head>
<body>
<!-- start header -->
<div class="header_bg">
<div class="wrap">
	<div class="header">
		<div class="logo">
			<a href="index.php"><img src="images/castherm-comercio-e-servico-de-instrumentacao.jpg" alt="" width="150" height="87"/> </a>
</div>
		<div class="h_icon">
		<ul class="icon1 sub-icon1">
			<li><a class="active-icon c1" href="#"><i>(11) 4614-4073</i>
            <br><i>(11) 4614-4263</i></a>
				<ul class="sub-icon1 list">
					<li><h3>Entre em contato conosco</h3><a href=""></a></li>
					<li><p><a href="contact.php">contato@castherm.com.br</a></p></li>
				</ul>
			</li>
		</ul>
		</div>
<div class="h_search">
contato@castherm.com.br
</div> 

		<div class="clear"></div>
	</div>
</div>
</div>
<div class="header_btm">
<div class="wrap">
	<div class="header_sub">
<div class="h_menu">
<ul>
<li class="active"><a href="index.php">Home</a></li> |
<li><a href="temperatura.php">Temperatura</a></li> |
<li><a href="umidade.php">Umidade</a></li> |
<li><a href="pressao.php">Pressão</a></li> |
<li><a href="vazao-e-fluxo.php">Vazão e Fluxo</a></li> |
<li><a href="sobre-a-castherm-instrumentos.php">Sobre a Castherm</a></li> |
<li><a href="localizacao.php">Localização</a></li> |
<li><a href="contato.php">Contato</a></li>

</ul>
</div>
<div class="top-nav">
<nav class="nav">	        	
<a href="#" id="w3-menu-trigger"> </a>
<ul class="nav-list" style="">
<li class="nav-item"><li><a href="index.php">Home</a></li> 
<li class="nav-item"><li><a href="temperatura.php">Temperatura</a></li>
<li class="nav-item"><li><a href="umidade.php">Umidade</a></li>
<li class="nav-item"><li><a href="pressao.php">Pressão</a></li>
<li class="nav-item"><li><a href="vazao-e-fluxo.php">Vazão e Fluxo</a></li>
<li class="nav-item"><li><a href="sobre-a-castherm-instrumentos.php">Sobre a Castherm</a></li>
<li class="nav-item"><li><a href="localizacao.php">Localização</a></li>
<li class="nav-item"><li><a href="contato.php">Contato</a></li>
</ul>
</nav>
<div class="search_box">
</div>
<div class="clear"> </div>
<script src="js/responsive.menu.js"></script>

         </div>		  
	<div class="clear"></div>
</div>
</div>
</div>
<!-- start main -->
<div class="main_bg">
<div class="wrap">	
	<div class="main">
	<!-- start content -->
	<div class="single">
			<!-- start span1_of_1 -->
			<div class="left_content">
			<div class="span1_of_1">
				<!-- start product_slider -->
				<div class="product-view">
				    <div class="product-essential">
				        <div class="product-img-box">
				    <div class="more-views" style="float:left;">
				    </div>
<div class="product-image"> 
<img src="images/produtos/controlador-de-temperatura-sct1040-castherm.jpg" alt="Controlador de Temperatura SCT1040 Castherm" width="300" height="355" title="Controlador de Temperatura SCT1040 Castherm" />
</div>
					</div>
				</div>
				</div>
				<!-- end product_slider -->
			</div>
			<!-- start span1_of_1 -->
			<div class="span1_of_1_des">
				  <div class="desc1">
					<h3>Controlador de Temperatura SCT1040</h3>
					<p>O controlador de temperatura microprocessado SCT1040 foi desenvolvido para aplicações onde se deseja reunir baixo custo e alta precisão. Seu novo invólucro possui profundidade reduzida, somente 75 mm, o que também reduz significativamente o espaço de montagem.</p>
					<div class="available">
					  <div class="btn_form">
                      Preço sob orçamento<br>
                        <a href="contato.php" class="link">Faça um orçamento</a>
					  </div>
					  <div class="clear"></div>
					</div>
					<div class="share-desc">
						<div class="clear"></div>
					</div>
			   	 </div>
		   	  </div>
			   	<div class="clear"></div>
			   	<!-- start tabs -->
				   	<section class="tabs">
		            <input id="tab-1" type="radio" name="radio-set" class="tab-selector-1" checked="checked">
			        <label for="tab-1" class="tab-label-1">Descrição</label>
			
<!--    <input id="tab-2" type="radio" name="radio-set" class="tab-selector-2">
<label for="tab-2" class="tab-label-2">TAGS</label> -->
		            
	          
				    <div class="clear-shadow"></div>
					
			        <div class="content" scrolling="yes" >
				        <div class="content-1" > 
				          <p>O <strong>controlador de temperatura microprocessado SCT1040</strong> foi desenvolvido para aplicações onde se deseja reunir baixo custo e alta precisão. Seu novo invólucro possui profundidade reduzida, somente 75 mm, o que também reduz significativamente o espaço de montagem.                          Outra grande inovação do <strong>SCT1040 </strong>é o seu sistema de conexão elétrica removível que possibilita maior agilidade na etapa de instalação.                          Aceita termoresistência Pt100 e termopares J, K e T.  Tem duas saídas para controle ou alarme, alimentação universal, além de sintonia automática dos parâmetros PID, tornando o controlador de temperatura mais sofisticado e de baixo custo do mercado.                           Características Técnicas do <strong>controlador de temperatura microprocessado SCT1040 </strong>                          Entrada para termopares J, K, T e termorresistência Pt100, sem qualquer alteração de hardware ou recalibração<br>
                          <br>
                          Auto-sintonia dos parâmetros PID<br>
                          <br>
                          Saídas: Pulso lógico (ideal para acionar relés de estado sólido) e 1 relé SPST<br>
                          <br>
                          As saídas possuem 2 funções programáveis: controle ou alarme<br>
                          <br>
                          Funções de alarme: Mínimo, Máximo, Diferencial, Diferencial mínimo, Diferencial Máximo, Sensor Aberto<br>
                          <br>
                          Duas funções de alarme direcionadas para uma mesma saída<br>
                          <br>
                          Fonte de alimentação chaveada universal confere alta precisão ao instrumento mesmo em condições de oscilações na tensão da rede<br>
                          <br>
                          Função saída segura que permite ao usuário estabelecer a condição da saída de controle em caso de falha no sensor<br>
                          <br>
                          Função LBD (Loop Break Detection). Percebe falhas na malha de controle<br>
                          <br>
                          O <strong>controlador de temperatura microprocessado SCT1040 </strong>possui Menu de programação simplificado. Fácil operação pelo operador<br>
                          <br>
                          Número de série eletrônico indelével com 8 dígitos, acessível pelo display<br>
                          <br>
                          Proteção da configuração por senha de acesso<br>
                          <br>
                          Teclas em silicone<br>
                          <br>
                          Painel frontal: IP65<br>
                          <br>
                          * Produto beneficiado pela Legislação de Informática.
                          </p>
				          <div class="clear"></div>
						</div>
<!--   <div class="content-2">
<p class="para">  <div class="contact-form">

<div class="clear"></div>		
</div> -->
						</div>
			        </div>
			        
		         	<!-- end tabs -->
			   	</div>
			   	<!-- start sidebar -->
			 <div class="left_sidebar">
			   <div class="sellers">
						<h4>Instrumentos</h4>
						<div class="single-nav">
			                <ul>
			                   <li><a href="temperatura.php">Temperatura</a></li>
			                    <li><a href="umidade.php" title="Umidade">Umidade</a></li>
			                    <li><a href="pressao.php" title="Pressão">Pressão</a></li>
			                    <li><a href="vazao-e-fluxo.php" title="Vazão e Fluxo">Vazão e Fluxo</a></li>

			                </ul>
                 </div>
						  <div class="banner-wrap bottom_banner color_link"></div>
					</div>
				</div>
					<!-- end sidebar -->
          	    <div class="clear"></div>
	       </div>	
	<!-- end content -->
	</div>
</div>
</div>		
<!-- start footer -->
<div class="footer_bg">
  <div class="wrap">
    <div class="footer">
      <!-- start grids_of_4 -->
      <div class="grids_of_4">
        <div class="grid1_of_4">
          <h4>Informações Úteis</h4>
          <ul class="f_nav">
            <li><a href="sobre-a-castherm.php">Sobre a Castherm</a></li>
            <li></li>
            <li></li>
          </ul>
        </div>
        <div class="grid1_of_4">
          <h4>Instrumentos</h4>
          <ul class="f_nav">
            <li><a href="temperatura.php">Temperatura</a></li>
            <li><a href="umidade.php">Umidade</a></li>
            <li><a href="pressao.php">Pressão</a></li>
            <li><a href="vazao-e-fluxo.php">Vazão e Fluxo</a></li>
          </ul>
        </div>
        <div class="grid1_of_4">
          <h4>Endereço</h4>
          <ul class="f_nav">
            <li>A Castherm está localizada:</li>
            <li>Rua Belém, 17 | Jardim dos Ipês</li>
            <li>Cotia | São Paulo</li>
            <li>Cep: 06716-170</li>
          </ul>
        </div>
        <div class="grid1_of_4">
          <h4>Contatos castherm</h4>
          <ul class="f_nav">
            <li>Telefone: (11) 4614-4073</li>
            <li>Telefone: (11)  4614-4263</li>
            <li>Telefone: (11) 4614-4295</li>
            <li>E-mail: <a href="mailto:contato@castherm.com.br">contato@castherm.com.br</a></li>
          </ul>
        </div>
        <div class="clear"></div>
      </div>
    </div>
  </div>
</div>
<!-- start footer -->
<div class="footer_bg1">
  <div class="wrap">
    <div class="footer">
      <!-- scroll_top_btn -->
      <script type="text/javascript">
			$(document).ready(function() {
			
				var defaults = {
		  			containerID: 'toTop', // fading element id
					containerHoverID: 'toTopHover', // fading element hover id
					scrollSpeed: 1200,
					easingType: 'linear' 
		 		};
				
				
				$().UItoTop({ easingType: 'easeOutQuart' });
				
			});
		</script>
      <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
      <!--end scroll_top_btn -->
      <div class="copy">
        <p class="link">&copy;  Todos os direitos Reservados Castherm  Comércio e Serviços de Instrumentos de  Medição e Automatização Ltda </p>
      </div>
      <div class="clear"></div>
    </div>
  </div>
</div>
</body>
</html>